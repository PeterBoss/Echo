package shared;

public class ProtocolStrings {
  public static final String STOP = "##STOP##";
}